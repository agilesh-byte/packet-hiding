﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;
using System.Runtime.Serialization.Formatters.Binary;
using System.Collections;
using System.Security.Cryptography;
using System.IO;
using Intermediate_Node;
using qunatumkey;


namespace SERVER_NODE
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        ListViewItem lvi = new ListViewItem();
        
        private void Form1_Load(object sender, EventArgs e)
        {
            label1.Visible = false;
            label2.Visible = false;
            label3.Visible = false;
            label4.Visible = true;
            label5.Visible = true;
            label9.Visible = true;
            label10.Visible = true;
            label11.Visible = true;
            
            richTextBox1.Visible = false;
            listBox1.Visible = false;
            textBox2.Visible = false;
            btnallornothing.Visible = false;
            btnencrypt.Visible = false;
            btnsenddata.Visible = false;
            btnbrowser.Visible = false;
            textBox1.Visible = false;
            Control.CheckForIllegalCrossThreadCalls = false;
            backgroundWorker1.RunWorkerAsync();
            Control.CheckForIllegalCrossThreadCalls = false;
            backgroundWorker2.RunWorkerAsync();
        }
        public void puzzleack()
        {
            TcpListener tl = new TcpListener(IPAddress.Any, 1000);
            tl.Start();
            Socket soc = tl.AcceptSocket();
            NetworkStream ns = new NetworkStream(soc);
            BinaryFormatter bf = new BinaryFormatter();
            object solvepuzzle = bf.Deserialize(ns);
            //object filetype = bf.Deserialize(ns);
            //object filename = bf.Deserialize(ns);
            listView1.Enabled = false;
            if (solvepuzzle.ToString() == "INTER NODE1 SOLVED")
            {
                MessageBox.Show(label1.Text = solvepuzzle.ToString());
                listView1.Items[0].Checked = true;
              //  CheckSpecific(listView1,"INTER NODE1");
                
            }
            else if (solvepuzzle.ToString() == "INTER NODE2 SOLVED")
            {
                MessageBox.Show(label2.Text = solvepuzzle.ToString());
                listView1.Items[1].Checked = true;
            }
            else if (solvepuzzle.ToString() == "INTER NODE3 SOLVED")
            {
                MessageBox.Show(label3.Text = solvepuzzle.ToString());
                listView1.Items[2].Checked = true;
            }
            else if (solvepuzzle.ToString() == "Destination")
                MessageBox.Show("File Successfully Received Destination", "DESTINATION");


            tl.Stop();
            soc.Close();
            ns.Close();

            if (soc.Connected == false)
                puzzleack();

        }
        //public void CheckSpecific(ListView lvw, string str)
        //{
        //    lvw.Items.OfType<ListViewItem>().ToList().Find(str => item.Checked = true);
        //}
        public void nodeinfo()
        {
            TcpListener tl = new TcpListener(IPAddress.Any, 2000);
            tl.Start();
            Socket soc = tl.AcceptSocket();
            NetworkStream ns = new NetworkStream(soc);
            BinaryFormatter bf = new BinaryFormatter();
            object avilablenode = bf.Deserialize(ns);
            object systemname = bf.Deserialize(ns);

            if (avilablenode.ToString() == "INTER 1")
            {
                lvi = listView1.Items.Add(avilablenode.ToString());
                lvi.SubItems.Add(systemname.ToString());
            }
            else if (avilablenode.ToString() == "INTER 2")
            {
                lvi = listView1.Items.Add(avilablenode.ToString());
                lvi.SubItems.Add(systemname.ToString());
            }
            else if (avilablenode.ToString() == "INTER 3")
            {
                lvi = listView1.Items.Add(avilablenode.ToString());
                lvi.SubItems.Add(systemname.ToString());
            }
            //filetype.ToString() == label4.Text;
            label9.Text = avilablenode.ToString();
            //filename.ToString() == label5.Text;
            label11.Text = systemname.ToString();
            tl.Stop();
            ns.Close();
            soc.Close();
            
            if (soc.Connected == false)
                nodeinfo();
        }



        private void backgroundWorker1_DoWork(object sender, DoWorkEventArgs e)
        {
            nodeinfo();
        }

        private void backgroundWorker2_DoWork(object sender, DoWorkEventArgs e)
        {
            puzzleack();
        }

        //commitment scheam//
        public void comitment()
        {
            try
            {



                Hashtable ht = new Hashtable();

                ht.Add("INTER 1", "3000");

                ht.Add("INTER 2", "3001");
                ht.Add("INTER 3", "3002");
                for (int i = 0; i < listView1.CheckedItems.Count; i++)
                {
                    string s = listView1.CheckedItems[i].Text.ToString();
                    int n = Convert.ToInt32(ht[listView1.CheckedItems[i].Text].ToString());

                    string hostname = listView1.Items[i].SubItems[1].Text;

                    TcpClient tc = new TcpClient(hostname, n);
                    //  TcpClient tc = new TcpClient(s, n);
                    NetworkStream ns = tc.GetStream();
                    BinaryFormatter bf = new BinaryFormatter();
                    //bf.Serialize(ns, "INTER 1");
                    bf.Serialize(ns, s);
                    tc.Close();
                    ns.Close();
                }
                string str;
                str = listView1.CheckedItems[0].Text;
                str = listView1.CheckedItems[1].Text;
                str = listView1.CheckedItems[2].Text;

                //listView1.Items[0].Checked = false;
                //    lvi.Checked=false;
                //    lvi = listView1.CheckedItems[1];
                //    lvi.Checked = false;
                //lvi = listView1.CheckedItems[2];
                //lvi.Checked = false;

                CheckAllItems(listView1, false);
            }
            catch (Exception)
            { 
            
            }

        }

       

        public void CheckAllItems(ListView lvw, bool check)
        {
            lvw.Items.OfType<ListViewItem>().ToList().ForEach(item => item.Checked = check);
        }
        private void btncommitment_Click(object sender, EventArgs e)
        {
            comitment();
            textBox1.Visible = true;
            btnbrowser.Visible = true;
            label4.Visible = false;
            label5.Visible = false;
          
        }
        int i;
        private void btnallornothing_Click(object sender, EventArgs e)
        {
            btnencrypt.Visible = true;
            listBox1.Visible = true;
          //  StreamWriter sw = File.CreateText(@"D:\To College 2012\Vedha\DOTNET 0th REVIEW\ID 33 packet hiding\full project\PACKET HIDING\SERVER NODE\SERVER NODE\bin\Debug\files\" + label11.Text + label10.Text + label9.Text + "");
            StreamWriter sw = File.CreateText(Application.StartupPath + "\\files\\" + label11.Text + label10.Text + label9.Text + "");
            sw.Write(richTextBox1.Text);
            sw.Close();
            folderBrowserDialog1.ShowDialog();
            textBox1.Text = folderBrowserDialog1.SelectedPath.ToString();
            ListViewItem viewitem = new ListViewItem();
            DirectoryInfo dir = new DirectoryInfo(textBox1.Text);
            FileInfo[] fi;
            fi = dir.GetFiles();

            for (i = 0; i < fi.Length; i++)
            {

                listBox1.Items.Add(fi[i].Name.ToString());

            }

        }
        //Encrypt//
        public static string Encrypt(string plainText, string passPhrase, string saltValue, string hashAlgorithm, int passwordIterations, string initVector, int keySize)
        {
            byte[] initVectorBytes = Encoding.ASCII.GetBytes(initVector);
            byte[] saltValueBytes = Encoding.ASCII.GetBytes(saltValue);
            byte[] plainTextBytes = Encoding.UTF8.GetBytes(plainText);
            PasswordDeriveBytes password = new PasswordDeriveBytes(passPhrase, saltValueBytes, hashAlgorithm, passwordIterations);
            byte[] keyBytes = password.GetBytes(keySize / 8);
            RijndaelManaged symmetricKey = new RijndaelManaged();
            symmetricKey.Mode = CipherMode.CBC;
            ICryptoTransform encryptor = symmetricKey.CreateEncryptor(keyBytes, initVectorBytes);
            MemoryStream memoryStream = new MemoryStream();
            CryptoStream cryptoStream = new CryptoStream(memoryStream, encryptor, CryptoStreamMode.Write);
            cryptoStream.Write(plainTextBytes, 0, plainTextBytes.Length);
            cryptoStream.FlushFinalBlock();
            byte[] cipherTextBytes = memoryStream.ToArray();
            memoryStream.Close();
            cryptoStream.Close();

            string cipherText = Convert.ToBase64String(cipherTextBytes);
            return cipherText;
        }

        private void btnencrypt_Click(object sender, EventArgs e)
        {
            richTextBox1.Visible = false;
            btnallornothing.Visible = false;
            textBox2.Visible = true;
            btnsenddata.Visible = true;
            textBox2.Text = Encrypt(listBox1.Items.ToString(), "hi", "saltValue", "SHA1", 2, "@1B2c3D4e5F6g7H8", 256);

        }


        private void btnbrowser_Click(object sender, EventArgs e)
        {
            richTextBox1.Visible = true;
            btnallornothing.Visible = true;

            openFileDialog1.ShowDialog();
            textBox1.Text = openFileDialog1.FileName;
            listBox1.Items.Add(openFileDialog1.FileName);
            richTextBox1.LoadFile(openFileDialog1.FileName, RichTextBoxStreamType.PlainText);

        }
        int count;

        private void btnsenddata_Click(object sender, EventArgs e)
        {
            btnencrypt.Visible = false;
            listBox1.Visible = false;
            Hashtable ht = new Hashtable();
            ht.Add("INTER 1", "3000");
            ht.Add("INTER 2", "3001");
            ht.Add("INTER 3", "3002");
            for (int i = 0; i < listView1.CheckedItems.Count; i++)
            {
                string s = listView1.CheckedItems[i].ToString();
                int n = Convert.ToInt32(ht[listView1.CheckedItems[i].Text].ToString());

                string hostname = listView1.Items[i].SubItems[1].Text;

                TcpClient tc = new TcpClient(hostname, n);
                NetworkStream ns = tc.GetStream();
                BinaryFormatter bf = new BinaryFormatter();
                bf.Serialize(ns, "message");
                bf.Serialize(ns, textBox2.Text);
                tc.Close();
                ns.Close();

            }

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

    }
}

        
    
