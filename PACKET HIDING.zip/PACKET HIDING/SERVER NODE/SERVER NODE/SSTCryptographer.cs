using System;
using System.Collections.Generic;
using System.Text;
using System.Web;
using System.Security.Cryptography;

namespace Intermediate_Node
{
   public class SSTCryptographer
    {
        private static string _Key;

       

        public static string _key
        {
            set
            {
                _key = value;
            }
        }
       public static string Encrypt(string strEncrypt)
       {
           try
           {
               return Encrypt(strEncrypt, _Key);
           }
           catch (Exception ex)
           {
               return "Wrong Input." + ex.Message;

           }
       }
       public static string Decrypt(string strEncrypted)
       {
           try
           {
               return Decrypt(strEncrypted, _Key);
           }
           catch (Exception ex)
           {
               return "Wrong Input. " + ex.Message;
           }

       }
       public static string Encrypt(string strToEncrypt, string strKey)
       {
           try
           {
               TripleDESCryptoServiceProvider objDESCrypto = new TripleDESCryptoServiceProvider();
               MD5CryptoServiceProvider objHashMD5 = new MD5CryptoServiceProvider();
               byte[] byteHash, bytebuff;
               string StrTEmpkey = strKey;

               byteHash = objHashMD5.ComputeHash(ASCIIEncoding.ASCII.GetBytes(StrTEmpkey));
               objHashMD5 = null;
               objDESCrypto.Key = byteHash;
               objDESCrypto.Mode = CipherMode.ECB;
               bytebuff = ASCIIEncoding.ASCII.GetBytes(strToEncrypt);
               return Convert.ToBase64String(objDESCrypto.CreateEncryptor().TransformFinalBlock(bytebuff, 0, bytebuff.Length));
           }
           catch (Exception ex)
           {
               return "Wrong Input. " + ex.Message;
           }
       }
       public static string Decrypt(string strEncrypted, string strKey)
       {
           try
           {
               TripleDESCryptoServiceProvider objDESCrypto = new TripleDESCryptoServiceProvider();
               MD5CryptoServiceProvider objHashMD5 = new MD5CryptoServiceProvider();
               byte[] byteHash, bytebuff;
               string StrTEmpkey = strKey;

               byteHash = objHashMD5.ComputeHash(ASCIIEncoding.ASCII.GetBytes(StrTEmpkey));
               objHashMD5 = null;
               objDESCrypto.Key = byteHash;
               objDESCrypto.Mode = CipherMode.ECB;

               bytebuff = Convert.FromBase64String(strEncrypted);
               string strDecrypted = ASCIIEncoding.ASCII.GetString(objDESCrypto.CreateDecryptor().TransformFinalBlock(bytebuff, 0, bytebuff.Length));
               objDESCrypto = null;
               return strDecrypted;

           }
           catch (Exception ex)
           {
               return "Wrong Input." + ex.Message;
           }
       }


       
    }

}
