﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;
using System.Data.SqlClient;
using System.Net;
using System.Net.Sockets;
using System.Runtime.Serialization.Formatters.Binary;

namespace INTER_NODE2
{
    public partial class Form1 : Form
    {
        SqlConnection con = new SqlConnection("Data Source=nanda;Initial Catalog=packethiding;user id=sa;");
        private Thread timerThread = null;
        static int min = 0;

        public Form1()
        {
            InitializeComponent();
        }
        private void timerFunc()
        {
            string str;

            for (int sec = 0; sec < 60; sec++)
            {
                str = string.Format(" Puzzle  00:0{0}:{1} ", min, sec);
                this.Text = str;
                Thread.Sleep(1000);
                if (sec == 20)
                {
                    this.Enabled = false;
                    this.Hide();
                }
            }
        }
       

        private void button18_Click(object sender, EventArgs e)
        {
            SqlCommand cmd = new SqlCommand("select *from puzzlekey where  password=@password", con);
            cmd.Parameters.Add("@password", SqlDbType.NVarChar, 50).Value = textBox1.Text;
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                MessageBox.Show("Your Selected for Comitment Node");
                TcpClient tc = new TcpClient("nanda", 1000);
                NetworkStream ns = tc.GetStream();
                BinaryFormatter bf = new BinaryFormatter();
                bf.Serialize(ns, "INTER NODE2 SOLVED");
                


            }
            else
            {
                MessageBox.Show(" You Are Hacker ", "You Lose the Game!");



            }
        }

        private void btnd_Click(object sender, EventArgs e)
        {
            textBox1.AppendText("D");
        }

        private void button5_Click(object sender, EventArgs e)
        {
            textBox1.AppendText("E");
        }

        private void button6_Click(object sender, EventArgs e)
        {
            textBox1.AppendText("F");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            textBox1.AppendText("A");
        }

        private void button11_Click(object sender, EventArgs e)
        {
            textBox1.AppendText("K");
        }

        private void button13_Click(object sender, EventArgs e)
        {
            textBox1.AppendText("M");
        }

        private void button14_Click(object sender, EventArgs e)
        {
            textBox1.AppendText("N");
        }

        private void button15_Click(object sender, EventArgs e)
        {
            textBox1.AppendText("O");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.AppendText("B");
        }

        private void button12_Click(object sender, EventArgs e)
        {
            textBox1.AppendText("L");
        }

        private void button10_Click(object sender, EventArgs e)
        {
            textBox1.AppendText("J");
        }

        private void button22_Click(object sender, EventArgs e)
        {
            textBox1.AppendText("V");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            textBox1.AppendText("C");
        }

        private void button7_Click(object sender, EventArgs e)
        {
            textBox1.AppendText("G");
        }

        private void button19_Click(object sender, EventArgs e)
        {
            textBox1.AppendText("S");
        }

        private void button23_Click(object sender, EventArgs e)
        {
            textBox1.AppendText("W");
        }

        private void button24_Click(object sender, EventArgs e)
        {
            textBox1.AppendText("X");
        }

        private void button20_Click(object sender, EventArgs e)
        {
            textBox1.AppendText("T");
        }

        private void button21_Click(object sender, EventArgs e)
        {
            textBox1.AppendText("U");
        }

        private void button25_Click(object sender, EventArgs e)
        {
            textBox1.AppendText("Y");
        }

        private void button16_Click(object sender, EventArgs e)
        {
            textBox1.AppendText("P");
        }

        private void button17_Click(object sender, EventArgs e)
        {
            textBox1.AppendText("Q");
        }

        private void button26_Click(object sender, EventArgs e)
        {
            textBox1.AppendText("Z");
        }

        private void button8_Click(object sender, EventArgs e)
        {
            textBox1.AppendText("H");
        }

        private void button9_Click(object sender, EventArgs e)
        {
            textBox1.AppendText("I");
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Control.CheckForIllegalCrossThreadCalls = false;

            timerThread = new Thread(new ThreadStart(timerFunc));
            timerThread.IsBackground = true;
            timerThread.Start();
        }
    }
}
