﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Net.Sockets;
using System.Runtime.Serialization.Formatters.Binary;
using System.Net;

namespace INTER_NODE2
{
    public partial class INTER_NODE2 : Form
    {
        public INTER_NODE2()
        {
            InitializeComponent();
        }
        Form1 forms = new Form1();
        private void INTER_NODE2_Load(object sender, EventArgs e)
        {
            lblpuzzle.Visible = false;
            pictureBox1.Visible = false;

            Control.CheckForIllegalCrossThreadCalls = false;
            backgroundWorker1.RunWorkerAsync();
        //    TcpClient tc = new TcpClient(Environment.MachineName, 2000);
            TcpClient tc = new TcpClient("localhost", 2000);
            NetworkStream ns = tc.GetStream();
            BinaryFormatter bf = new BinaryFormatter();
            bf.Serialize(ns, "INTER 2");
            bf.Serialize(ns, Environment.MachineName);
            tc.Close();
            ns.Close();
        }
        public void commitment()
        {
            TcpListener tl = new TcpListener(IPAddress.Any, 3001);
            tl.Start();
            Socket soc = tl.AcceptSocket();
            NetworkStream ns = new NetworkStream(soc);
            BinaryFormatter bf = new BinaryFormatter();
            object acceptcommitment = bf.Deserialize(ns);
            if (acceptcommitment.ToString() == "INTER 2")
            {
                
                //object ob = bf.Deserialize(ns);
                textBox1.Text = acceptcommitment.ToString();
                MessageBox.Show(acceptcommitment.ToString());
            }
            lblpuzzle.Visible = true;
            pictureBox1.Visible = true;
            if (acceptcommitment.ToString() == "message")
            {
                object ob = bf.Deserialize(ns);
                textBox1.Text = ob.ToString();
            }
            
            tl.Stop();
            soc.Close();
            ns.Close();
            if (soc.Connected == false)
                commitment();
        }

        private void backgroundWorker1_DoWork(object sender, DoWorkEventArgs e)
        {
            commitment();
        }

        private void label1_Click(object sender, EventArgs e)
        {
           
        }

        private void btnsenddata_Click(object sender, EventArgs e)
        {
            TcpClient tc = new TcpClient("localhost", 4000);
            NetworkStream ns = tc.GetStream();
            BinaryFormatter bf = new BinaryFormatter();
            bf.Serialize(ns, "INTER 2");
            bf.Serialize(ns, textBox1.Text);
            tc.Close();
            ns.Close();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            forms.Show();
        }
    }
}
