﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;
using System.Runtime.Serialization.Formatters.Binary;

namespace INTER_NODE_1
{
    public partial class INTER_NODE1 : Form
    {
        public INTER_NODE1()
        {
            InitializeComponent();
        }
        Form1 forms = new Form1();

        private void INTER_NODE1_Load(object sender, EventArgs e)
        {
            pictureBox2.Visible = false;
            lblpuzzle.Visible = false;
            Control.CheckForIllegalCrossThreadCalls = false;
            backgroundWorker1.RunWorkerAsync();
            TcpClient tc = new TcpClient(Environment.MachineName, 2000);
            NetworkStream ns = tc.GetStream();
            BinaryFormatter bf = new BinaryFormatter();
            bf.Serialize(ns, "INTER 1");
            bf.Serialize(ns, Environment.MachineName);
            tc.Close();
            ns.Close();
        }
         public void StartTimer()

{



    timer1.Start();

   timer1.Tick +=new EventHandler(timer1_Tick);

 

}
        public void commitment()
        {
            TcpListener tl = new TcpListener(IPAddress.Any, 3000);
            tl.Start();
            Socket soc = tl.AcceptSocket();
            NetworkStream ns = new NetworkStream(soc);
            BinaryFormatter bf = new BinaryFormatter();
            object acceptcommitment = bf.Deserialize(ns);


            if (acceptcommitment.ToString() == "INTER 1")
            {
                MessageBox.Show(acceptcommitment.ToString());
                //object ob = bf.Deserialize(ns);
                textBox1.Text = acceptcommitment.ToString();
               
            }
            lblpuzzle.Visible = true;
            pictureBox2.Visible = true;
            if (acceptcommitment.ToString() == "message")
            {
                object ob = bf.Deserialize(ns);
                    textBox1.Text=ob.ToString();
            }
          
            tl.Stop();
            soc.Close();
            ns.Close();
            if (soc.Connected == false)
                commitment();
        }

        private void backgroundWorker1_DoWork(object sender, DoWorkEventArgs e)
        {
            commitment();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            
        }
       

        private void timer1_Tick(object sender, EventArgs e)
        {
        //button1.BackColor = Color.Red;

        }

        private void btnsenddata_Click(object sender, EventArgs e)
        {
            TcpClient tc = new TcpClient(Environment.MachineName, 4000);
            NetworkStream ns = tc.GetStream();
            BinaryFormatter bf = new BinaryFormatter();
            bf.Serialize(ns, "INTER 1");
            bf.Serialize(ns,textBox1.Text);
            tc.Close();
            ns.Close();
            
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            forms.Show();
        }

        

 

    }
}
